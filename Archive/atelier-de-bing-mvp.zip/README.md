# L'Atelier de Bing

Python-first engineering toolbox.

Modules:
- Mechanical Design
- Utilities
- MyWork
