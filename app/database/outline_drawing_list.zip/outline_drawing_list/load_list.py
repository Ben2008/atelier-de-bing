import pandas as pd
import sqlite3

DB_NAME = "outline_drawing.db"

conn = sqlite3.connect(DB_NAME)

for file_name, source in [
    ("MS_list.csv", "MS"),
    ("SS_list.csv", "SS")
]:

    df = pd.read_csv(file_name)

    print(f"Processing {file_name}")

    first_col = df.columns[0]

    for drawing in df[first_col].dropna():

        drawing = str(drawing).strip()

        try:
            conn.execute("""
                INSERT OR IGNORE INTO drawing_master (
                    drawing_name,
                    source_list
                )
                VALUES (?, ?)
            """,
            (
                drawing,
                source
            ))

        except Exception as e:
            print(e)

conn.commit()
conn.close()