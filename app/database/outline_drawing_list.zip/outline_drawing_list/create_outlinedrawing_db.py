import sqlite3

DB_NAME = "outline_drawing.db"

conn = sqlite3.connect(DB_NAME)
cur = conn.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS drawing_master (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    drawing_name TEXT UNIQUE,
    source_list TEXT,

    motor_type TEXT,
    material TEXT,

    drum_diameter INTEGER,
    flange_style TEXT,
    shaft_size INTEGER,

    brake_option TEXT,

    stator TEXT,
    speed REAL,
    hp REAL,
    gear_code TEXT,

    phase INTEGER,
    frequency INTEGER,
    voltage INTEGER,

    power_entry TEXT,

    face_width REAL,
    shell_profile TEXT,
    surface_finish TEXT,

    drawing_category TEXT,

    parse_status TEXT DEFAULT 'RAW'
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS lagging_profile (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    drawing_id INTEGER,

    lagging_material TEXT,
    lagging_thickness REAL,
    lagging_profile TEXT,

    FOREIGN KEY(drawing_id)
        REFERENCES drawing_master(id)
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS drawing_geometry (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    drawing_id INTEGER,

    shaft_cross_section TEXT,
    shaft_x REAL,
    shaft_y REAL,

    FOREIGN KEY(drawing_id)
        REFERENCES drawing_master(id)
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS drawing_sprockets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    drawing_id INTEGER,

    series TEXT,
    teeth INTEGER,
    material TEXT,
    quantity INTEGER,

    FOREIGN KEY(drawing_id)
        REFERENCES drawing_master(id)
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS drawing_drive_rods (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    drawing_id INTEGER,

    rod_count INTEGER,
    series TEXT,

    FOREIGN KEY(drawing_id)
        REFERENCES drawing_master(id)
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS drawing_features (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    drawing_id INTEGER,

    feature_code TEXT,
    feature_value TEXT,

    FOREIGN KEY(drawing_id)
        REFERENCES drawing_master(id)
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS token_dictionary (
    token TEXT PRIMARY KEY,

    description TEXT,
    category TEXT,
    active INTEGER DEFAULT 1
)
""")

conn.close