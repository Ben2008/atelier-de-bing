
import pandas as pd
from pathlib import Path

DB_FILE = Path("data/vdg_motor_catalog.xlsx")

def load_database():
    return pd.read_excel(DB_FILE)
