
from .database import load_database

def find_matches(drum_dia_mm, speed_ft_min, limit=10):
    df = load_database().copy()
    df["score"] = (
        abs(df["Drum_DIA_mm"] - drum_dia_mm)
        + abs(df["V_ft_min"] - speed_ft_min)
    )
    return df.sort_values("score").head(limit).to_dict("records")
