
from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates
from app.services.vdg_motor.search import find_matches

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/utilities/vdg-motor")
def page(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="vdg_motor.html",
        context={"results":[]}
    )

@router.get("/api/vdg-motor")
def query(drum_dia_mm: float, speed_ft_min: float):
    return find_matches(drum_dia_mm, speed_ft_min)
